package com.example.vibratewidget

import android.media.AudioManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.permissionButton)

        toggleButton.setOnClickListener {
            toggleVibrateMode()
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val isVibrate = audioManager.ringerMode == AudioManager.RINGER_MODE_VIBRATE

        if (isVibrate) {
            statusText.text = "Aktualny tryb: WIBRACJA\n\nKliknij przycisk lub użyj widgetu na ekranie głównym."
            toggleButton.text = "Przełącz na dzwonek"
        } else {
            statusText.text = "Aktualny tryb: DZWONEK\n\nKliknij przycisk lub użyj widgetu na ekranie głównym."
            toggleButton.text = "Przełącz na wibrację"
        }
    }

    private fun toggleVibrateMode() {
        if (audioManager.ringerMode == AudioManager.RINGER_MODE_VIBRATE) {
            audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
        } else {
            audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
        }
        updateStatus()
    }
}
