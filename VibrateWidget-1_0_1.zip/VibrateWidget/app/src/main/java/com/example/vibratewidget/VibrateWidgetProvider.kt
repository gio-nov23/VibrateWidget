package com.example.vibratewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.widget.RemoteViews
import android.widget.Toast

class VibrateWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE_VIBRATE = "com.example.vibratewidget.TOGGLE_VIBRATE"
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        if (intent.action == ACTION_TOGGLE_VIBRATE) {
            toggleVibrateMode(context)

            // Update all widgets
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(
                ComponentName(context, VibrateWidgetProvider::class.java)
            )
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }

    private fun toggleVibrateMode(context: Context) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val currentMode = audioManager.ringerMode

        if (currentMode == AudioManager.RINGER_MODE_VIBRATE) {
            // Switch to normal mode
            audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
            Toast.makeText(context, "Dzwonek", Toast.LENGTH_SHORT).show()
        } else {
            // Switch to vibrate mode
            audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            Toast.makeText(context, "Wibracja", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateAppWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int
    ) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val isVibrate = audioManager.ringerMode == AudioManager.RINGER_MODE_VIBRATE

        val views = RemoteViews(context.packageName, R.layout.widget_vibrate)

        // Update icon based on current state
        if (isVibrate) {
            views.setImageViewResource(R.id.widget_icon, R.drawable.ic_vibrate_on)
            views.setInt(R.id.widget_background, "setBackgroundResource", R.drawable.widget_background_active)
        } else {
            views.setImageViewResource(R.id.widget_icon, R.drawable.ic_vibrate_off)
            views.setInt(R.id.widget_background, "setBackgroundResource", R.drawable.widget_background)            
        }

        // Set click action
        val intent = Intent(context, VibrateWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE_VIBRATE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_background, pendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
